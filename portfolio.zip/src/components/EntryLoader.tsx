'use client'

import { useState, useEffect } from 'react'

interface EntryLoaderProps {
  onComplete: () => void
}

const EntryLoader = ({ onComplete }: EntryLoaderProps) => {
  const [progress, setProgress] = useState(0)
  const [showDoorTransition, setShowDoorTransition] = useState(false)
  const [isExiting, setIsExiting] = useState(false)
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false)

  useEffect(() => {
    // Check for reduced motion preference
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)')
    setPrefersReducedMotion(mediaQuery.matches)
    
    // Lock body scroll on mount
    document.body.style.overflow = 'hidden'
    
    return () => {
      // Restore body scroll on unmount
      document.body.style.overflow = ''
    }
  }, [])

  useEffect(() => {
    // Progress animation over 1.5 seconds (0 to 100%)
    const progressInterval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval)
          return 100
        }
        return prev + 6.67 // 100% over 1.5 seconds (6.67% every 100ms)
      })
    }, 100)

    // Start curtain reveal transition after 1.5 seconds
    const curtainTimer = setTimeout(() => {
      setShowDoorTransition(true)
      
      // Complete and trigger page reveal after 100ms (at 1.6s total) to prevent blank screen
      setTimeout(() => {
        sessionStorage.setItem('entryLoaderSeen', '1')
        sessionStorage.setItem('welcomeShown', '1') // Mark welcome as shown
        onComplete()
      }, 100) // 100ms delay so Hero starts at exactly 1.6s
    }, 1500) // 1.5s total duration

    return () => {
      clearInterval(progressInterval)
      clearTimeout(curtainTimer)
    }
  }, [onComplete])

  // Calculate stroke-dashoffset for ring (276 is circumference)
  const strokeDashoffset = 276 - (progress / 100) * 276

  return (
    <>
      {/* CSS for animations */}
      <style jsx>{`
        @keyframes goldGlow {
          0%, 100% { 
            text-shadow: 0 0 20px rgb(212 175 55 / 0.6);
          }
          50% { 
            text-shadow: 0 0 40px rgb(212 175 55 / 0.9), 0 0 60px rgb(212 175 55 / 0.5);
          }
        }
        
        @keyframes lightSweep {
          0% { 
            background-position: -200% 0;
          }
          100% { 
            background-position: 200% 0;
          }
        }
        
        .gold-glow {
          animation: goldGlow 2s ease-in-out infinite;
        }
        
        .light-sweep {
          background: linear-gradient(
            90deg,
            transparent 0%,
            transparent 40%,
            rgba(212, 175, 55, 0.3) 50%,
            transparent 60%,
            transparent 100%
          );
          background-size: 200% 100%;
          animation: lightSweep 2s ease-in-out infinite;
          -webkit-background-clip: text;
          background-clip: text;
        }
        
        .gold-glow-disabled {
          text-shadow: 0 0 20px rgb(212 175 55 / 0.4);
        }
      `}</style>

      <div 
        className={`fixed inset-0 z-[100] flex items-center justify-center bg-black overflow-hidden ${
          showDoorTransition ? 'pointer-events-none' : ''
        }`}
      >
        {/* Top Curtain Panel */}
        <div 
          className={`absolute top-0 left-0 w-full h-1/2 bg-black border-b border-white/5 transition-transform duration-[400ms] ease-[cubic-bezier(0.22,1,0.36,1)] ${
            showDoorTransition ? '-translate-y-full' : 'translate-y-0'
          }`}
        />
        
        {/* Bottom Curtain Panel */}
        <div 
          className={`absolute bottom-0 left-0 w-full h-1/2 bg-black border-t border-white/5 transition-transform duration-[400ms] ease-[cubic-bezier(0.22,1,0.36,1)] ${
            showDoorTransition ? 'translate-y-full' : 'translate-y-0'
          }`}
        />
        
        {/* Main Content */}
        <div className="relative z-10 flex flex-col items-center text-center">
          {/* WELCOME Text */}
          <h1 className="text-[clamp(56px,10vw,120px)] md:text-9xl font-black text-white tracking-tighter leading-none mb-8">
            <span 
              className={`inline-block text-[#D4AF37] ${
                prefersReducedMotion ? 'gold-glow-disabled' : 'gold-glow'
              }`}
            >
              W
            </span>
            <span 
              className={prefersReducedMotion ? '' : 'light-sweep'}
            >
              ELCOME
            </span>
            <span className="text-[#D4AF37]">.</span>
          </h1>
          
          {/* Progress Ring */}
          <div className="relative w-24 h-24 flex items-center justify-center">
            <svg className="w-full h-full -rotate-90">
              {/* Background ring */}
              <circle 
                cx="48" 
                cy="48" 
                r="44" 
                stroke="currentColor" 
                strokeWidth="2" 
                fill="transparent" 
                className="text-zinc-900"
              />
              {/* Progress ring */}
              <circle 
                cx="48" 
                cy="48" 
                r="44" 
                stroke="currentColor" 
                strokeWidth="2" 
                fill="transparent" 
                strokeDasharray="276" 
                strokeDashoffset={strokeDashoffset}
                className="text-[#D4AF37] transition-all duration-75 ease-out"
                style={{
                  filter: 'drop-shadow(0 0 8px rgb(212 175 55 / 0.6))'
                }}
              />
            </svg>
            {/* Percentage Text */}
            <span className="absolute text-sm font-mono text-white">
              {Math.round(progress)}%
            </span>
          </div>
        </div>
      </div>
    </>
  )
}

export default EntryLoader